package com.example.green1

import java.io.Serializable

data class MyClass(var title :String?, var address : String?, var date : String, var text : String?) : Serializable {

}