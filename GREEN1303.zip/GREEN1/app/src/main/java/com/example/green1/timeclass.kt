package com.example.green1

class timeclass(var name:String, var tel:String, var homepage:String,var start1:String, var end1:String, var start2:String,var end2:String,
                var fee1:String, var fee2:String, var fee3:String, var info:String) {
}